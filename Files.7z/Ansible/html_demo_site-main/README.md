# Welcome to Sammy's HTML demo site!

This is a repostitory containing the files for the [demonstration website](https://html.sammy-codes.com) in the DigitalOcean tutorial series [How To Build a Website With HTML](https://www.digitalocean.com/community/tutorial_series/how-to-build-a-website-with-html).

You can follow along the tutorial series to recreate these files while learning how to use HTML. Or use these files as a test site for following our tutorial [How To Deploy a Static Website to the Cloud with DigitalOcean’s App Platform](https://www.digitalocean.com/community/tutorials/how-to-deploy-a-static-website-to-the-cloud-with-digitalocean-s-app-platform).  

